package edu.umkc.asteroid.archInterfaces;


public interface IGame {
	
	public void startGame();
	
	public void killPlayer();	
	
	public void resetGame();
	
	public void resetEntityLists();
	
	public boolean areEnemiesDead();
	
	
}
